<x-filament-panels::page>
    @livewire(\App\Filament\Widgets\CalendarGoogle::class) 
</x-filament-panels::page>

