

<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startPush('head'); ?>
        <style>
            body {
                font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif !important;            
            }
            .zoom-container {
                position: relative;
                width: 100vw;  // 100% da largura da viewport
                height: 100vh; // 100% da altura da viewport
                overflow: auto; // Permite a rolagem se necessário
                display: flex;
                justify-content: flex-start; // Alinha o conteúdo à esquerda
                align-items: flex-start; // Ancora o conteúdo no topo do container
            }
            .filament-table-container table {
                width: auto;
                min-width: 100%;
                border-collapse: collapse;
                transform-origin: left top; // Muda o ponto de origem para o canto esquerdo superior
                transition: transform 0.3s ease;
            }
            th, td {
                border: 1px solid #ccc !important;
                text-align: center;
                padding: 10px; /* Espaçamento adequado dentro das células */
            }
            th {
                background-color: #f2f2f2 !important;
            }
            .dateline {
                width: 100%;
                text-align: center;
            }
            /* Estilos adicionais para as cores de fundo das linhas baseadas no service_id */
            .service-1 { background-color: #D8EAD3 !important;; }
            .service-3 { background-color: #FEF2CC !important; }
            .cleaning {
                background-color: #FEF2CC !important;
            }
            .title {
                background-color: #F6B26B !important;
            }
            .non-cleaning {
                background-color: #D8EAD3 !important;
            }
            .empty {
                background-color: white !important;
            }
        </style>        
    <?php $__env->stopPush(); ?>
    
    <div class="container">
        <?php 
            $maxOrders = $buildings->reduce(function ($carry, $building) {
                return max($carry, $building->orders->where('status', 'DONE')->count());
            }, 0);
        ?>
        <div class="flex space-x-2 items-center">
            <!-- Botões aqui -->
            <!-- Botões de Zoom fora do .zoom-container -->
            <?php if (isset($component)) { $__componentOriginalf0029cce6d19fd6d472097ff06a800a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon-button','data' => ['onclick' => 'zoomIn()','icon' => 'heroicon-m-plus','color' => 'success','label' => 'Zoom + ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'zoomIn()','icon' => 'heroicon-m-plus','color' => 'success','label' => 'Zoom + ']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $attributes = $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $component = $__componentOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
            <!-- Botões de Zoom fora do .zoom-container -->
            <?php if (isset($component)) { $__componentOriginalf0029cce6d19fd6d472097ff06a800a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon-button','data' => ['onclick' => 'zoomOut()','icon' => 'heroicon-m-minus','color' => 'danger','label' => 'Zoom - ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'zoomOut()','icon' => 'heroicon-m-minus','color' => 'danger','label' => 'Zoom - ']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $attributes = $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $component = $__componentOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
        </div>
        <?php
            $totalColunas = 0;
            foreach ($buildings as $building) {
                // Cada edifício contribui com pelo menos 1 coluna (PAINT).
                $totalColunas += 1;        
                // Se o edifício tiver ordens de CLEANING, adiciona mais 1 coluna.
                if ($building->hasCleaning) {
                    $totalColunas += 1;
                }
            }
        ?>
        <div id="zoomContainer" class="zoom-container">  
            <table style="    
                    border: 1px solid #272626 !important;   
                    width: auto; /* Ajusta automaticamente a largura baseada no conteúdo */
                    min-width: 100%; /* Garante no mínimo a largura do container */
                    border-collapse: collapse; /* Espaços de borda colapsados */
                    transform-origin: center center; /* Ajusta o ponto de origem para o topo e centro */
                    transition: transform 0.3s ease; /* Suaviza a transformação */
                ">
                <thead style="border: 1px solid #272626;">
                    <tr style="background-color: #F6B26B;">
                       <th colspan="<?php echo e($totalColunas); ?>" style="text-align: center;">Work Done</th>
                    </tr>
                    <tr style="background-color: #F6B26B">
                        <th colspan="<?php echo e($totalColunas); ?>" style="text-align: center;">APR 1 - APR 6, 2024</th>
                    </tr>

                    <!-- Ajuste o valor de colspan para corresponder ao número total de colunas -->
                    </tr>
                    <tr style="background-color: #F6B26B;">            
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th style="border: 1px solid #272626; background-color: #F6B26B" <?php echo e($building->hasCleaning ? 'colspan=2' : ''); ?>><?php echo e($building->name_wwd); ?>

                            <!--[if BLOCK]><![endif]--><?php if($building->wwdpay): ?> <!-- Acessando um único Wwdpay relacionado -->
                                <br /><?php echo e($building->wwdpay->description); ?>

                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </th> <!-- Coluna única ou duas colunas dependendo de hasCleaning -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tr>
                    <!--[if BLOCK]><![endif]--><?php if($buildings->contains->hasCleaning): ?> <!-- Verifica se algum dos edifícios tem ordens de Cleaning -->
                        <tr>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th style="border: 1px solid #272626; background-color: #F6B26B">PAINT</th> <!-- Sempre exibe a coluna PAINT -->
                                <!--[if BLOCK]><![endif]--><?php if($building->hasCleaning): ?>
                                    <th style="border: 1px solid #272626; background-color: #F6B26B">CLEANING</th> <!-- Exibe a coluna Cleaning somente se o edifício tem ordens de Cleaning -->
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php for($i = 0; $i < $maxOrders; $i++): ?>
                        <tr style="min-height: 50px; min-width: 50px; vertical-align: top;">
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ordersForRow = $building->orders->where('status', 'DONE');
                                    $nonCleaningOrder = $ordersForRow->where('service_id', '<>', 3)->skip($i)->first();
                                    $cleaningOrder = $ordersForRow->where('service_id', '=', 3)->skip($i)->first();
                                    if ($cleaningOrder) {
                                        $cleaningOrder_record = $cleaningOrder->id;
                                    }
                                    if ($nonCleaningOrder) {
                                        $cleaningOrder_record = $nonCleaningOrder->id;
                                    }
                                   
                                ?> 
                                <td style="<?php echo e($nonCleaningOrder ? 'background-color: #D8EAD3;
                                    border: 1px solid #272626 !important; 
                                    text-align: center;
                                    
                                    ' : 'background-color: defaultColor;                        
                                '); ?>">
                                     <div style="min-height: 50px; min-width: 150px; !important">
                                        <!--[if BLOCK]><![endif]--><?php if($nonCleaningOrder): ?>
                                            <div class="flex justify-end">
                                                <button wire:click="editOrder(<?php echo e($nonCleaningOrder->id); ?>)">Editar Pedido</button>

                                               
                                            </div>
                                             
                                            <?php echo e($nonCleaningOrder->unit ?? 'N/A'); ?> <br /> (<?php echo e($nonCleaningOrder->size ?? 'N/A'); ?>) <br /><br />
                                            <?php echo e($nonCleaningOrder->description ?? 'N/A'); ?><br /> 
                                        <?php else: ?>
                                            &nbsp;
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </td>
                                <!--[if BLOCK]><![endif]--><?php if($building->hasCleaning): ?> 

                                    <td style="<?php echo e($cleaningOrder ? 'background-color: #FEF2CC;
                                      border: 1px solid #272626 !important; 
                                    text-align: center;
                                   
                                    ' : 'background-color: defaultColor;                        
                                '); ?>">

                                    
                                        <div style="min-height: 50px; min-width: 150px; !important">
                                            <!--[if BLOCK]><![endif]--><?php if($cleaningOrder): ?>
                                                <div class="flex justify-end">
                                                    <?php if (isset($component)) { $__componentOriginalf0029cce6d19fd6d472097ff06a800a1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.icon-button','data' => ['wire:click' => '$emit(\'editOrder\', '.e($nonCleaningOrder->id).')','icon' => 'heroicon-m-ellipsis-horizontal','color' => 'warning','tooltip' => 'Edit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::icon-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => '$emit(\'editOrder\', '.e($nonCleaningOrder->id).')','icon' => 'heroicon-m-ellipsis-horizontal','color' => 'warning','tooltip' => 'Edit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $attributes = $__attributesOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__attributesOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1)): ?>
<?php $component = $__componentOriginalf0029cce6d19fd6d472097ff06a800a1; ?>
<?php unset($__componentOriginalf0029cce6d19fd6d472097ff06a800a1); ?>
<?php endif; ?>
                                                </div>    
                                                

                                                 
                                                <?php echo e($nonCleaningOrder->unit ?? 'N/A'); ?> (<?php echo e($nonCleaningOrder->size ?? 'N/A'); ?>) <br /><br />
                                                <?php echo e($cleaningOrder->description ?? 'N/A'); ?> (<?php echo e($cleaningOrder->description ?? 'N/A'); ?>) <br /><br />
                                                
                                            <?php else: ?>
                                                &nbsp;
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                        
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </tr>
                    <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>
    
    <?php $__env->startPush('scripts'); ?>   
        <script>
            var currentScale = 1.0; // Escala inicial de 100%
            function zoomIn() {
                currentScale *= 1.1; // Aumenta a escala em 10%
                applyZoom();
            }
            function zoomOut() {
                currentScale = Math.max(0.5, currentScale - 0.1); // Diminui a escala, mínimo de 50%
                applyZoom();
            }
            function applyZoom() {
                var zoomContainer = document.getElementById('zoomContainer');
                zoomContainer.style.transform = `scale(${currentScale})`;
                zoomContainer.style.transformOrigin = 'left top'; // Mantém o ponto de origem à esquerda no topo
            }
            window.addEventListener('resize', adjustZoomToFit);
            function adjustZoomToFit() {
                var zoomContainer = document.getElementById('zoomContainer');
                var scaleWidth = window.innerWidth / zoomContainer.offsetWidth;
                zoomContainer.style.transform = `scale(${scaleWidth})`;
                zoomContainer.style.transformOrigin = 'left top'; // Mantém a tabela ancorada no canto esquerdo superior
            }
          
                document.addEventListener('DOMContentLoaded', function () {
                    // Adicionar listeners para botões, etc.
                    Array.from(document.querySelectorAll('.edit-order-button')).forEach(button => {
                        button.addEventListener('click', () => {
                            window.location.href = button.getAttribute('data-url');
                        });
                    });
                });

                  
        </script>    
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\customers\onequality\onequalitysystem\resources\views/filament/pages/workdone.blade.php ENDPATH**/ ?>