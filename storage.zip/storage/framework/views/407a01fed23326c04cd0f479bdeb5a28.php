<div>
    <?php if (isset($component)) { $__componentOriginale1cebc129855f156aa8f78d22103aca1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale1cebc129855f156aa8f78d22103aca1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.breadcrumbs','data' => ['breadcrumbs' => [
        '/' => 'Home',
        '/Tasks' => 'Tasks',
        '/Tasks/Import' => 'Import from Google',
    ]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament::breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['breadcrumbs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
        '/' => 'Home',
        '/Tasks' => 'Tasks',
        '/Tasks/Import' => 'Import from Google',
    ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale1cebc129855f156aa8f78d22103aca1)): ?>
<?php $attributes = $__attributesOriginale1cebc129855f156aa8f78d22103aca1; ?>
<?php unset($__attributesOriginale1cebc129855f156aa8f78d22103aca1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale1cebc129855f156aa8f78d22103aca1)): ?>
<?php $component = $__componentOriginale1cebc129855f156aa8f78d22103aca1; ?>
<?php unset($__componentOriginale1cebc129855f156aa8f78d22103aca1); ?>
<?php endif; ?>
    <h1>Import From Google</h1>
    <div class="flex justify-between mt-3">
        <div class="font-bold text-3xl">Events</div>
    </div>
    <div class="flex items-center space-x-2">    
        <form wire:submit.prevent="save" class="w-full flex items-center space-x-2">
            <input class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-6" type="date" wire:model="dateFrom" required>
            <input class="shadow appearance-none border rounded py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-6" type="date" wire:model="dateTo" required>
            <select class="shadow appearance-none border rounded py-2 px-13 text-gray-700 leading-tight focus:outline-none focus:shadow-outline mr-6" wire:model="status" required>
                <option value="">Select Status</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="all">All</option>
            </select>
            <button class="bg-red-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">
                Import From Google Calendar
            </button>
        </form>
        <!-- Botão adicional removido; já incluso na parte do formulário -->
        <button wire:click="consistbuildings" class="bg-red-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">
            Processar Buildings
        </button>
        <button wire:click="exportToOrders" class="bg-yellow-500 hover:bg-blue-700 text-white font-bold py-2 
                   px-4 rounded focus:outline-none focus:shadow-outline">
            Export to Orders
        </button>
    </div>

</div>
<?php /**PATH C:\customers\onequality\onequalitysystem\resources\views/filament/events/importfromgoogle.blade.php ENDPATH**/ ?>