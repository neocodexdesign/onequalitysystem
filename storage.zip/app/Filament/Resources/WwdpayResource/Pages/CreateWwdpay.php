<?php

namespace App\Filament\Resources\WwdpayResource\Pages;

use App\Filament\Resources\WwdpayResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWwdpay extends CreateRecord
{
    protected static string $resource = WwdpayResource::class;
}
