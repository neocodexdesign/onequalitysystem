<?php

namespace App\Filament\Resources\WorkdoneUpResource\Pages;

use App\Filament\Resources\WorkdoneUpResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateWorkdoneUp extends CreateRecord
{
    protected static string $resource = WorkdoneUpResource::class;
}
