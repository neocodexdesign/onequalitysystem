<h1>
    {{$event->name}}
</h1>
