<x-filament-panels::page>
    @livewire(\App\Filament\Widgets\CalendarWidget::class)
</x-filament-panels::page>
